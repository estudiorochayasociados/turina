<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="images/icons/favicon.png">

<!-- All css files are included here. -->
<!-- Bootstrap fremwork main css -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/bootstrap.min.css">
<!-- nivo slider CSS -->
<link rel="stylesheet" href="<?=URL;?>/assets/lib/css/nivo-slider.css"/>
<!-- This core.css file contents all plugings css file. -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/core.css">
<!-- Theme shortcodes/elements style -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/shortcode/shortcodes.css">
<!-- Theme main style -->
<link rel="stylesheet" href="<?=URL;?>/style.css">
<!-- Responsive css -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/responsive.css">
<!-- Template color css -->
<link href="<?=URL;?>/assets/css/color/color-core.css" data-style="styles" rel="stylesheet">
<!-- User style -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/custom.css">
<!-- User Estilos -->
<link rel="stylesheet" href="<?=URL;?>/assets/css/estilos.css">
<!-- Font-awesome CSS -->
<link rel="stylesheet" href="<?=URL; ?>/assets/css/all.min.css">
<!-- bigimg -->
<link rel="stylesheet" href="<?=URL;?>/assets/bigimg/lib/view-bigimg.css">

<!-- Modernizr JS -->
<script src="<?=URL;?>/js/vendor/modernizr-2.8.3.min.js"></script>